<?php

declare(strict_types=1);
/**
 * To add a BC compatibility:
 * require_once __DIR__ . '/BC/SomeFile.php';
 */
