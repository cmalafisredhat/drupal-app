<?php
/**
 * Dummy file to make autoloaders work
 *
 * PHP version 5
 *
 * @category PEAR
 * @package  PEAR
 * @author   Christian Weiske <cweiske@php.net>
 * @license  http://opensource.org/licenses/bsd-license.php New BSD License
 * @link     http://pear.php.net/package/PEAR
 */
require_once __DIR__ . '/../PEAR.php';
?>