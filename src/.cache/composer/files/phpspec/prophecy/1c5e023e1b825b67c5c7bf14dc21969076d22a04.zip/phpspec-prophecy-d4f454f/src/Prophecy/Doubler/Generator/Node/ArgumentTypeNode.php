<?php

namespace Prophecy\Doubler\Generator\Node;

use Prophecy\Exception\Doubler\DoubleException;

class ArgumentTypeNode extends TypeNodeAbstract
{

}
