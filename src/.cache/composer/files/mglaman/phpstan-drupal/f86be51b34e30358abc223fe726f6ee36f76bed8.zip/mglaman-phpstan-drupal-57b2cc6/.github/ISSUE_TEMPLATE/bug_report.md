---
name: Bug report
about: Something isn't working right
title: ''
labels: bug
assignees: ''

---

# Bug report

<!-- Before reporting an issue please check that you are using the latest PHPStan and phpstan-drupal versions! -->
<!-- composer update phpstan/phpstan mglaman/phpstan-drupal -->

<!-- Please describe your problem here. -->

### Code snippet that reproduces the problem

<!-- Code example or link to public code scanned -->
