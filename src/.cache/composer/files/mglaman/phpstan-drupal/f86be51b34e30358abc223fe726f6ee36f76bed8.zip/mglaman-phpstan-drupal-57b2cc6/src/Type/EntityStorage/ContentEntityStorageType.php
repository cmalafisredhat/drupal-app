<?php

declare(strict_types=1);

namespace mglaman\PHPStanDrupal\Type\EntityStorage;

final class ContentEntityStorageType extends EntityStorageType
{

}
