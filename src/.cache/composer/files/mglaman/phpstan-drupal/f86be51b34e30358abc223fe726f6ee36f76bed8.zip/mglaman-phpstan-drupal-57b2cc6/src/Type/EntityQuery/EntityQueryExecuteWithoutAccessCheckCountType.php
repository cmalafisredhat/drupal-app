<?php

declare(strict_types=1);

namespace mglaman\PHPStanDrupal\Type\EntityQuery;

use PHPStan\Type\IntegerType;

final class EntityQueryExecuteWithoutAccessCheckCountType extends IntegerType
{

}
