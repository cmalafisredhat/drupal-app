<?php declare(strict_types=1);

namespace mglaman\PHPStanDrupal\Type\EntityQuery;

/**
 * Type used to represent an entity query instance as count query.
 */
final class EntityQueryCountType extends EntityQueryType
{

}
